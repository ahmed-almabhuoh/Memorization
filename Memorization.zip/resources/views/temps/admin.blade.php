@extends('layouts.admin')

@section('title', 'Title Page')

@section('styles')
    
@endsection

@section('content')

@endsection

@section('scripts')
    
@endsection