@extends('layouts.admin')

@section('title', 'Manager Dashboard')

@section('styles')
    
@endsection

@section('content')
    
@endsection

@section('scripts')
    
@endsection