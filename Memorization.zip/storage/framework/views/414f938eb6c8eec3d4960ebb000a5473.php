<?php $__env->startSection('title', 'Add new keep'); ?>

<?php $__env->startSection('styles'); ?>



    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card card-custom">
        <div class="card-header">
            <h3 class="card-title">
                Add New keep for <?php echo e($student->fname); ?> in <?php echo e($group->name); ?> group
            </h3>
            <div class="card-toolbar">
                <div class="example-tools justify-content-center">
                    <span class="example-toggle" data-toggle="tooltip" title="View code"></span>
                    <span class="example-copy" data-toggle="tooltip" title="Copy code"></span>
                </div>
            </div>
        </div>
        <!--begin::Form-->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('keeps.create-livewire', [
        'student' => $student,
        'group' => $group,
        ])->html();
} elseif ($_instance->childHasBeenRendered('Dg8KB0j')) {
    $componentId = $_instance->getRenderedChildComponentId('Dg8KB0j');
    $componentTag = $_instance->getRenderedChildComponentTagName('Dg8KB0j');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Dg8KB0j');
} else {
    $response = \Livewire\Livewire::mount('keeps.create-livewire', [
        'student' => $student,
        'group' => $group,
        ]);
    $html = $response->html();
    $_instance->logRenderedChild('Dg8KB0j', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <!--end::Form-->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function store(student_id, group_id) {
            const formData = new FormData();
            formData.append('student_id', student_id);
            formData.append('group_id', group_id);
            formData.append('from_juz', document.getElementById('from_juz').value);
            formData.append('to_juz', document.getElementById('to_juz').value);
            formData.append('from_surah', document.getElementById('from_surah').value);
            formData.append('to_surah', document.getElementById('to_surah').value);
            formData.append('from_ayah', document.getElementById('from_ayah').value);
            formData.append('to_ayah', document.getElementById('to_ayah').value);
            formData.append('fault_number', document.getElementById('fault_number').value);

            axios.post('/auto/keeps/store', formData)
                .then(function (response) {
                    toastr.success(response.data.message);
                    document.getElementById('creation-form').reset();
                })
                .catch(function (error) {
                    toastr.error(error.response.data.message);
                });
        }
    </script>

    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Memorization\resources\views/backend/keeps/store.blade.php ENDPATH**/ ?>