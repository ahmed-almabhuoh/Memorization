<form id="creation-form">
    <div class="card-body">

        <div class="form-group">
            <label for="from_juz">Start Juz <span class="text-danger">*</span></label>
            <select class="form-control" id="from_juz" wire:model="selectedStartJuz">
                <option value="0">-- Select keep Juz --</option>
                <?php for($i = 1; $i <= 30; ++$i): ?>
                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="to_juz">End Juz <span class="text-danger">*</span></label>
            <select class="form-control" id="to_juz">
                <option value="">-- Select keep Juz --</option>
                <?php for($i = 1; $i <= 30; ++$i): ?>
                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="from_surah">Start Surah <span class="text-danger">*</span></label>
            <select class="form-control" id="from_surah">
                <option value="0">-- Select keep start surah --</option>
                <?php $__currentLoopData = $juzs_response->surahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($surah->number); ?>"><?php echo e($surah->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="to_surah">End Surah <span class="text-danger">*</span></label>
            <select class="form-control" id="to_surah">
                <option value="">-- Select keep end surah --</option>
                <?php $__currentLoopData = $juzs_response->surahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($surah->number); ?>"><?php echo e($surah->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label>From Ayah <span class="text-danger">*</span></label>
            <input type="number" class="form-control" placeholder="Enter keep from ayah ..." id="from_ayah"/>
        </div>

        <div class="form-group">
            <label>To Ayah <span class="text-danger">*</span></label>
            <input type="number" class="form-control" placeholder="Enter keep to ayah ..." id="to_ayah"/>
        </div>

        <div class="form-group">
            <label>Faults number <span class="text-danger">*</span></label>
            <input type=" number" class="form-control" placeholder="Enter faults number ..." id="fault_number"/>
        </div>

        <div class="card-group">
            <button type="button" onclick="store('<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($student->id)); ?>', '<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($group->id)); ?>')" class="btn btn-primary mr-2">Store</button>
            <button type="reset" class="btn btn-secondary">Cancel</button>
        </div>
    </div>
</form>
<?php /**PATH C:\wamp64\www\Memorization\resources\views/livewire/keeps/create-livewire.blade.php ENDPATH**/ ?>