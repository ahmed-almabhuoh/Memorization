

<?php $__env->startSection('title', 'Add supervisor for <?php echo e($sc->name); ?>'); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        #supervisor-image {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: 1px solid rgb(44, 192, 214);
            padding: 3px;
        }
    </style>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card card-custom">
        <div class="card-header flex-wrap border-0 pt-6 pb-0">
            <div class="card-title">
                <h3 class="card-label"><?php echo e($sc->name); ?> committee
                    <span class="text-muted pt-2 font-size-sm d-block">Add supervisors to <?php echo e($sc->name); ?>

                        committee</span>
                </h3>
            </div>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-supervisor-to-supervision-committee-livewire', [
            'sc' => $sc,
            'supervisors' => $supervisors,
        ])->html();
} elseif ($_instance->childHasBeenRendered('jPUmZDz')) {
    $componentId = $_instance->getRenderedChildComponentId('jPUmZDz');
    $componentTag = $_instance->getRenderedChildComponentTagName('jPUmZDz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jPUmZDz');
} else {
    $response = \Livewire\Livewire::mount('add-supervisor-to-supervision-committee-livewire', [
            'sc' => $sc,
            'supervisors' => $supervisors,
        ]);
    $html = $response->html();
    $_instance->logRenderedChild('jPUmZDz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function add(id, s_id) {
            axios.post('/auto/supervisor-to-sc/' + id + '/supervisor/' + s_id)
                .then(function(response) {
                    // handle success
                    // showDeletingMessage(response.data);
                    toastr.success(response.data.message);
                })
                .catch(function(error) {
                    // handle error
                    // showDeletingMessage(error.response.data);
                    toastr.error(error.response.data.message);
                })
                .then(function() {
                    // always executed
                });
        }
    </script>

    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Memorization\resources\views/backend/supervision_committees/add-supervisors.blade.php ENDPATH**/ ?>